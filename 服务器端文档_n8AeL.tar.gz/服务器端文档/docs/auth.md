---
summary: "ClawHub sign-in, API tokens, CLI login, token storage, and revocation."
read_when:
  - Signing in to ClawHub
  - Using the ClawHub CLI
  - Debugging 401s
---

# Auth

ClawHub supports email verification codes plus GitHub, Google, and WeChat OAuth
for web sign-in. The CLI uses ClawHub API tokens created through that signed-in
account.

## Web sign-in

Enter your email address to receive an 8-digit one-time verification code, then
enter that code in the sign-in dialog. The verification-code field remains
visible before and after sending so password managers and browser OTP autofill
can target a stable form. Email addresses use the browser's email validation
and are limited to 38 characters.

A code is bound to the normalized email address that requested it. Changing the
email clears the entered code and invalidates the dialog's pending verification
state; request a new code for the new address. The client accepts digits only
and enables verification only after all 8 digits are present. You can also
choose **GitHub**, **Google**, or **WeChat**. These methods create the same type
of authenticated session; there is no password-based account.

If a verification code does not arrive, check the address and spam folder, then
retry after a short wait. Codes expire after 20 minutes and a successful newer
request replaces the code that was previously valid for that address. Contact
the site operator if the UI reports a server error or a valid code cannot be
verified.

Deleted, banned, or disabled accounts cannot complete normal ClawHub sign-in.
If sign-in returns you to a logged-out state, your account may not be in good
standing. If your account was banned or disabled, use the
[ClawHub appeal form](https://appeals.openclaw.ai/) if you believe this is a
mistake.

## CLI login

The default CLI login flow opens your browser:

```bash
clawhub login
clawhub whoami
```

What happens:

1. The CLI starts a temporary callback server on `127.0.0.1`.
2. Your browser opens the ClawHub sign-in page.
3. After GitHub sign-in, ClawHub creates an API token.
4. The browser redirects back to the local callback.
5. The CLI stores the token in your ClawHub config file.

If your browser cannot reach the local callback because of firewall, VPN, or
proxy rules, use the headless token flow.

## Headless login

Create a token in the ClawHub web UI, then pass it to the CLI:

```bash
clawhub login --token clh_...
```

Use this flow for servers, CI jobs, or terminal-only environments.

For remote shells where you can open a browser elsewhere, run:

```bash
clawhub login --device
```

The CLI prints a one-time code and waits while you authorize it at
`https://clawhub.ai/cli/device`.

## Token storage

Default config paths:

- macOS: `~/Library/Application Support/clawhub/config.json`
- Linux/XDG: `$XDG_CONFIG_HOME/clawhub/config.json` or `~/.config/clawhub/config.json`
- Windows: `%APPDATA%\\clawhub\\config.json`

Override the path with:

```bash
export CLAWHUB_CONFIG_PATH=/path/to/config.json
```

Print the stored token for CI setup with:

```bash
clawhub token
```

## Revocation

You can revoke API tokens in the ClawHub web UI.

Revoked, invalid, or missing tokens return `401 Unauthorized`. Sign in again
with `clawhub login` or provide a fresh token with `clawhub login --token`.

Deleted, banned, or disabled accounts cannot continue using existing API tokens.
If your account was banned or disabled, use the
[ClawHub appeal form](https://appeals.openclaw.ai/) if you believe this is a
mistake.
